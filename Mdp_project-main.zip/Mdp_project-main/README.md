# MUltiple Disease Prediction

  # ipnyb Files

    1. diabetes_Disease.ipnyb- detects the whether the person has diabetes or not based on the input symtoms values we give.

    2. Heart_Disease.ipnyb-1.diabetes.ipnyb-detects the whether the person has Heart disease or not based on the input symtoms values we give.
 
    3. Parkinsons_Disease.ipnyb-1.diabetes.ipnyb-detects the whether the person has Parkinsons Disease or not based on the input symtoms values we give.

   # Machine_learning_saved-Models

     1.diabetes_model.sav

     2.heart_disease_model.sav

     3.parkinsons_model.sav

     these saved models are used while deploying it on server and also while creating a web-application  

   # CSV Files
     
     3-csv-files one for each Disease Prediction

   # Streamlit.py

     This file has streamlit application code , it provides Gui interface and also,used for deployment of web-application on server 
